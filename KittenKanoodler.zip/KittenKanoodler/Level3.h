//
//  Level3.h
//  KittenKanoodler
//
//  Created by Christina Ramos on 11/8/14.
//  Copyright 2014 Christina Ramos. All rights reserved.
//

#import "Level2.h"

@interface Level3 : Level2 {
    
}

/** Gets a scene for this layer */
+ (CCScene *) scene;

/** Constructor */
- (id) init;

@end
