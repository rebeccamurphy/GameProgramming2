//
//  Level2.h
//  KittenKanoodler
//
//  Created by Christina Ramos on 11/8/14.
//  Copyright 2014 Christina Ramos. All rights reserved.
//

#import "Level1.h"

@interface Level2 : Level1 {
    
}

/** Gets a scene for this layer */
+ (CCScene *) scene;

/** Constructor */
- (id) init;

@end
