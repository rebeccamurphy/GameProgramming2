//
//  main.m
//  KittenKanoodler
//
//  Created by Christina Ramos on 10/6/14.
//  Copyright Christina Ramos 2014. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
