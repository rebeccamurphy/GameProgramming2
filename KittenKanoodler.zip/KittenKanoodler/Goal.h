//
//  Goal.h
//  iMGABaseCC
//
//  Created by Ron Coleman on 12/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Entity.h"

/** Goal for Grace to reach */
@interface Goal : Entity
- (Goal*) initAt:(CGPoint) point;
@end
